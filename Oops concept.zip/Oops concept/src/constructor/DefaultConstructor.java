package constructor;

public class DefaultConstructor {
   int id;
   String name;
   String department;
   
   //method to display the value of id,name and department.
   public void display() {
	   System.out.println(id+" "+name+" "+department);
   }
   public static void main(String[] args) {
	   DefaultConstructor s1=new DefaultConstructor();
	   DefaultConstructor s2=new DefaultConstructor();
	   s1.display();
	   s2.display();
}
}
