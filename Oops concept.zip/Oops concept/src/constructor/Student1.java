package constructor;

public class Student1 {
 int rollNo;
 String name;
 public Student1(int rollNo,String name) {
	 super();
	 this.rollNo=rollNo;
	 this.name=name;
 }
 
 
 @Override
public String toString() {
	return "Student1 [rollNo=" + rollNo + ", name=" + name + "]";
}


public static void main(String[] args) {
	Student1 s1=new Student1(1,"Gauri");
	System.out.println(s1);
	Student1 s2=new Student1(2,"Sheela");
	System.out.println(s2);
	Student1 s3=new Student1(3,"Rutuja");
	System.out.println(s3);
}
}
