package constructor;

import java.util.Arrays;

public class ArrayObject {
int id;
String name;

public ArrayObject(int id,String name) {
	super();
	this.id=id;
	this.name=name;
}
@Override
public String toString() {
	return "ArrayObject [id=" + id + ", name=" + name + "]";
}

public static void main(String[] args) {
	 ArrayObject a1=new ArrayObject(1,"Gauri");
	 ArrayObject a2=new ArrayObject(2,"Pallavi");
	 ArrayObject a3=new ArrayObject(3,"Sneha");
	 ArrayObject[] a=new ArrayObject[5];
	 a[0]=a1;
	 a[1]=a2;
	 a[2]=a3;
	 System.out.println(a[0]);
	 System.out.println(Arrays.toString(a));
	 int l=10;
	 int []l1=new int [10];
	 l1[0]=l;
	 System.out.println(l1[0]);
	 
}
}
