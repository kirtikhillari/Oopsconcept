package constructor;

public class Student {
int id;
String name;
String surname;

public Student(int id,String name,String surname) {
	super();
	this.id=id;
	this.name=name;
	this.surname=surname;
}
void display() {
	System.out.println(id+" "+name+" "+surname);
}

public static void main(String[] args) {
	Student s1=new Student(1,"Neha","Patil");
	Student s2=new Student(2,"Pari","Patil");
	Student s3=new Student(3,"Pallavi","Jadhav");
	s1.display();
	s2.display();
	s3.display();
}


}
