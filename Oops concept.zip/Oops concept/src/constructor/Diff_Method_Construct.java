package constructor;

/*
 * Java Constructor	                             Java Method
A constructor is used to initialize       A method is used to expose the behavior
the state of an object.	                  of an object.
A constructor must not have a return      A method must have a return type.
type.	
The constructor is invoked implicitly.	  The method is invoked explicitly.

The Java compiler provides a default      The method is not provided by the compiler
 constructor if you don't have any        in any case.
 constructor in a class.	
  
The constructor name must be same as      The method name may or may not be same
 the class name.	                      as the class name.
 */
public class Diff_Method_Construct {

}
