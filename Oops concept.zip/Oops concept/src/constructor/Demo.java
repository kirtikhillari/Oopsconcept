package constructor;

public class Demo {
/*
 * Constructor is used to initialize object attributes
 * constructor in java is special method
 * constructor don't have return type 
 * constructor name and class name should be same.
 * constructor can have any no of statement
 * super() can be used to call parent class constructor
 * super() is optional (if we are not declaring super() inside constructor compiler will put super() in constructor)
 * super() should be there in first line within constructor.
 * if programmer not creating constructor  compiler will provide constructor
 * 
 */
	//Compiler created constructor.
//	public Demo() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
	//user created constructor.
	public Demo() {
		super();
		System.out.println("Constructor created");
	}
	
	public static void main(String[] args) {
		//when we create object constructor will get call automatically.
		Demo d=new Demo();
		//we can't call constructor explicitly.
		//we can't call constructor like methods
		//d.Demo();
		//for every instance/object constructor will get call only once.
		Demo s1=new Demo();
	}

	
}
