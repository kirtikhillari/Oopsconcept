package constructor;
/*
 * 1)It is a special type of method which is used to initialize the object.
 * 2)Every time an object is created using the new() keyword, at least one constructor is called.
 * 3)It calls a default constructor if there is no constructor available in the class. In such
 *  case, Java compiler provides a default constructor by default.
 * 4)There are two types of constructors in Java: no-arg constructor, and parameterized 
 * constructor.
 * 
 * Rules for creating Java constructor: 
 * 1) Constructor name must be the same as its class name
   2) A Constructor must have no explicit return type
   3) A Java constructor cannot be abstract, static, final, and synchronized
   
   Syntax: 
     <class_name>(){}
 */
//Example of default constructor
public class BasicDemo {
	//creating a default constructor
	public BasicDemo() {
		System.out.println("Default Constructor is created");
		
	}
	public static void main(String[] args) {
		//calling default constructor
		BasicDemo b=new BasicDemo();
	}
}
//Q) What is the purpose of a default constructor?
//The default constructor is used to provide the default values to the object like 0, null, etc., depending on the type.
