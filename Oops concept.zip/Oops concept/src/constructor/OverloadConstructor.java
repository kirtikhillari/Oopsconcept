package constructor;

public class OverloadConstructor {
    int id;
    String name;
    int age;
    //creating two arg constructor
    public OverloadConstructor(int i,String n) {
    	id=i;
    	name=n;
    }
    //creating three arg constructor
   public OverloadConstructor(int i,String n,int a) {
	   id=i;
	   name=n;
	   age=a;
   }
   void display() {
	   System.out.println(id+" "+name+" "+age);
   }
   public static void main(String[] args) {
	   OverloadConstructor s1=new OverloadConstructor(111,"Karan");
	   OverloadConstructor s2=new OverloadConstructor(222,"Aryan",25);
	   s1.display();
	   s2.display();
}
}
