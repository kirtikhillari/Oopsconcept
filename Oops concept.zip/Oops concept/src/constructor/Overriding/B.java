package constructor.Overriding;

public class B {
public B() {
	super();
}
}
