package constructor.Overriding;

public class A {
//to achieve constructor overriding signature must be same
	//but it is not posssible in constructor 
	//so we can say constructor overriding is not possible.
	public A() {
		super();
	}
}
