package FinalAccessModifier;

//final access modifier 
//we can create object for final classes 
//we can't extend final class 
final class A {
  public static void main(String[] args) {
	A a1=new A();
}
}
