package FinalAccessModifier;
//if our class is final we can't extends that class.
//from same package and also from another package.
//method overriding is not possible if our class modifier is final
//public class B extends A{
//
//}
