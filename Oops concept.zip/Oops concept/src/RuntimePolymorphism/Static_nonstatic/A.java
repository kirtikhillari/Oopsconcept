package RuntimePolymorphism.Static_nonstatic;

// we can't override static and non-static merhods.
//static methods are class level method.
//non static methods are object level methods.
public class A {
    public static void m1() {
    	System.out.println("A class method");
    }
    public void m2() {
    	System.out.println("A class non static method");
    }
}
