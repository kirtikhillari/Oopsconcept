package RuntimePolymorphism.Static_nonstatic;

public class B extends A {
   public static void m1() {
	   System.out.println("B class method");
   }
   public void m2() {
	   System.out.println("B class non static method");
   }
   public static void main(String[] args) {
	A a1=new B();
	a1.m1();
	a1.m2();
}
}
