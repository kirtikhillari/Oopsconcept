package RuntimePolymorphism.Final;

//we can not override final method 
public class A {
  final void m1() {
	  System.out.println("A class method called");
  }
}
