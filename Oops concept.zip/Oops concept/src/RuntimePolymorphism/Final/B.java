package RuntimePolymorphism.Final;

public class B extends A {
//   final void m1() {
//	   System.out.println("B class method called");
//   }
}
