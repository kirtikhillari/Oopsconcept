package RuntimePolymorphism.CheckedException;

import java.io.FileNotFoundException;
import java.io.FileReader;

//throws will delegate exception handling request to the caller 
//if child class method throws any checked exception then in present class
//method also we have to throws same exception of its parent 

public class BB extends AA{
	//FileNotFoundException-checked Exception
   public void m1() throws FileNotFoundException{
	   //logic to get data from ab.txt file
   }
   public void m2() throws FileNotFoundException{
	   //logic
   }
//   public void m3() throws FileNotFoundException{
//	   //logic
//   }
   public void m4() throws FileNotFoundException{
	   FileReader f=new FileReader("/Users/Desktop");
   }
}
