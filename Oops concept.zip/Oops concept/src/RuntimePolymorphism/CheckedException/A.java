package RuntimePolymorphism.CheckedException;

//checked exception which are checked by compiler for smooth execution of program during runtime
public class A {
//   .
//   .
//   .
//   .
//   .
//   .
//   //fetch the content from txt file present on desktop(ab.txt)
//   //if the file is not present there may be a chance my program will terminate over 
//   //this line.
//   .
//   .
//   .
//   .
//   .
//   .
//   .
}
