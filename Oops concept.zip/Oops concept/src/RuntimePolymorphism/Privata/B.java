package RuntimePolymorphism.Privata;

public class B extends A{
   private void m1() {
	   System.out.println("B class method");
   }
   public static void main(String[] args) {
	A a1=new A();
//	a1.m1();  //we cannot override private method.
}
}
