package RuntimePolymorphism.Privata;

//we cannot overrride private methods.
public class A {
   private void m1() {
	   System.out.println("A class method");
   }
}
