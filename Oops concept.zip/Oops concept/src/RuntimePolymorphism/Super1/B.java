package RuntimePolymorphism.Super1;

public class B extends A{
  public void m1() {
	 super.m1();
	  //System.out.println("B class method");
  }
  public static void main(String[] args) {
	A a1=new B();
	a1.m1();
}
}
