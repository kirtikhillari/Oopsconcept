package RuntimePolymorphism.Super1;

public class A {
   public void m1() {
	   System.out.println("A class method");
   }
}
