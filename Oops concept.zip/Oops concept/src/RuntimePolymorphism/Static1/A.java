package RuntimePolymorphism.Static1;

//static methods resolution is taken care by compiler based on reference type
//we can't override static methods
//we can call it as method hiding.
public class A {
	public static void m1() {
		System.out.println("A class method");
	}
    public void m2() {
    	System.out.println("A class non static method");
    }
}
