package PublicDemo1;

import vision.PublicAccess.Modifier.A;

public class AA extends A {

}
