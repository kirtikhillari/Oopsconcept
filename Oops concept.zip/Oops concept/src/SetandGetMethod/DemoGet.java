package SetandGetMethod;

public class DemoGet {
  int i;
  String name;
  public int m1(){
  return i;
 }
  //getter method
  //if we want to see object attributes values we can call getter method.
public int getI() {
	return i;
}
public String getName() {
	return name;
}

public static void main(String[] args) {
	DemoGet d1=new DemoGet();
	System.out.println(d1.i);
	d1.m1();
	System.out.println(d1.m1());
	d1.getI();
	System.out.println(d1.getI());
	System.out.println(d1.getName());
}
}