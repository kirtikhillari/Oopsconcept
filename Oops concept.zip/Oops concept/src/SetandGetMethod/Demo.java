package SetandGetMethod;

public class Demo {
   int i;
   public void m1(int i) {
	   this.i=i;
   }
   //setter method
   //if we want to set values to object attributes we are generating setter method.
  public void setI(int i) {
	this.i = i;
}
@Override
public String toString() {
	return "Demo [i=" + i + "]";
}
   public static void main(String[] args) {
	Demo d=new Demo();
	d.i=10;
	System.out.println(d);
	//d.m1(10);
	d.setI(20);
	System.out.println(d);
	Demo d1=new Demo();
	d1.m1(30);
	System.out.println(d1);
}
}
