package Assignment1;

public class Addition {
  public static int add(int n1,int n2) {
	  int s;
	  s=n1+n2;
	  return s;
  }
  public static void main(String[] args) {
	 int a=19;
	 int b=5;
	 //method calling
	 int c=a+b;
	 System.out.println("The sum of a and b is= "+c);
}
}
