package Assignment1;

public class Accessor_MutatorMethod {
private int roll;
private String name;
public int getRoll()  //accessor method
{
	return roll;
}
public void setRoll(int roll)  //Mutator method
{
	this.roll=roll;
}
public String getName()   
{  
return name;  
}  
public void setName(String name)   
{  
this.name = name;  
}  
public void display() {
	System.out.println("Roll no : "+roll);
	System.out.println("Name is : "+name);
}
public static void main(String[] args) {
	Accessor_MutatorMethod a1=new Accessor_MutatorMethod();
	a1.display();
}
}
