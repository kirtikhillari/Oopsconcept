package Assignment1;
/*
 * There are two types of instance method:
 * 1) Accessor Method
 * 2) Mutator Method
 * 
 * Accessor Methos: The method(s) that reads the instance variable(s) is known as accessor method.
 *We can easily identify it because the method is prefixed with the word "get".It is also known as "getters".
 *It returns the value of the private field.It is used to get the value of the private field. 
 */

//Example: 
//	public int getId() {
//	return Id;
//}
/*
 * Mutator Method: The method(s) read the instance variables(s) and also modify the values. we can easily identify it because the method is prefixed with word "set".It is known as "setters" or"modifiers".
 * It does not return anything . It accepts a parameter of the same data type that depends on the field.
 * It is used to set the value of the private field.
 * 
 *  Example:
 *  public void setRoll(int roll){
 *  this.roll=roll;
 *  }
 */
public class BasicInstanceMethod {
    
}
