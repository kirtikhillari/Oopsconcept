package Assignment1;

public class StaticMethod {
 static void show() {
	 System.out.println("It is a static method");
 }
 public static void main(String[] args) {
	show();
}
}
