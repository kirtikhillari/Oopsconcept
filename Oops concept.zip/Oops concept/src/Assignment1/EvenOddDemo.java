package Assignment1;

import java.util.Scanner;

public class EvenOddDemo {
   public static void main(String[] args) {
	 Scanner s=new Scanner(System.in);
	 System.out.println("Enter the number : ");
	 
	 //reading value from the user
	 int num=s.nextInt();
	 //method calling
	 findEvenOdd(num);
}
   //user define method
   public static void findEvenOdd(int num) {
	   if(num%2==0)
		   System.out.println(num+" is even");
	   else
		   System.out.println(num+" is odd");
   }
}
