package vision.MultilevelInheritance;

public class A {
   public void methodA() {
	   System.out.println("Class A method");
   }
}
