package vision.MultilevelInheritance;
//Hierarchical inheritance
public class Parent {
  public void parentMethod() {
	  System.out.println("parent method called");
  }
}
