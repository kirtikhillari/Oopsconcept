package vision.MultilevelInheritance;

public class Child3 extends Parent {
	public void childMethod3(){
		System.out.println("child3 method called");
	}
	public static void main(String[] args) {
		//Child 3 object
		  Child3 c1=new Child3();
		  c1.parentMethod();
		  c1.childMethod3();
		  //Parent object
		  Parent p1=new Parent();
		  p1.parentMethod();
		  //child1 object using parent reference
		  Parent p2=new Child1();
		  p2.parentMethod();
		  //child1 object
		  Child1 c=new Child1();
		  c.parentMethod();
		  c.childMethod();
		  //child 2 object
		  Child2 c2=new Child2();
		  c2.parentMethod();
		  c2.childMethod2();
		//Child2 object using Parent reference
		  Parent p=new Child2();
		  p.parentMethod();
		 //Child1 object using Parent reference
		  Parent p3=new Child1();
		  p3.parentMethod();
	}
}
