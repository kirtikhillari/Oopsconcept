package vision.MultilevelInheritance;

public class Child1 extends Parent {
   public void childMethod() {
	   System.out.println("child 1 method called");
   }
   //when we are creating object with parent reference we can call only the methods of
   //parent class
   public static void main(String[] args) {
	//parent object
	   Parent p1=new Parent();
	   p1.parentMethod();
	   //child1 object
	   Child1 c1=new Child1();
	   c1.childMethod();
	   c1.parentMethod();
	   //child1 object using parent reference
	   Parent p2=new Child1();
	   p2.parentMethod();
	   
}
}
