package vision.MultilevelInheritance;

public class Child2 extends Parent {
	public void childMethod2(){
		System.out.println("child2 method called");
	}
  public static void main(String[] args) {
	//Child 2 object
	  Child2 c1=new Child2();
	  c1.parentMethod();
	  c1.childMethod2();
	  //Parent object
	  Parent p1=new Parent();
	  p1.parentMethod();
	  //child1 object using parent reference
	  Parent p2=new Child1();
	  p2.parentMethod();
	  //child1 object
	  Child1 c=new Child1();
	  c.parentMethod();
	  c.childMethod();
	  //child3 object
	  Child3 c2=new Child3();
	  c2.parentMethod();
	  c2.childMethod3();
	  //Child3 object using Parent reference
	  Parent p=new Child3();
	  p.parentMethod();
	 //Child1 object using Parent reference
	  Parent p3=new Child1();
	  p3.parentMethod();
}
}
