package vision.Constructor.Overloading;

//overloading is concept applicable to constructor also. 
public class Demo {
    int i;
    int j;
    int k;
    public Demo() {
    	super();
    	System.out.println("default constructor");
    }
    public Demo(int i) {
    	super();
    	this.i=i;
    	System.out.println("1 arg constructor");
    }
    public Demo(int i,int j) {
    	super();
    	this.i=i;
    	this.j=j;
    	System.out.println("2 arg constructor");
    }
    public Demo(int i,int j,int k) {
    	super();
    	this.i=i;
    	this.j=j;
    	this.k=k;
    	System.out.println("3 arg method");
    }
    public static void main(String[] args) {
		Demo d1=new Demo();
		Demo d2=new Demo(10);
		Demo d3=new Demo(20,30);
		Demo d4=new Demo(1,2,3);
	}
}
