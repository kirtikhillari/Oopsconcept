package vision.StaticOverloading;
//method overloading is called is allowed for static methods als
//method signature must be same.
//we can overload static method as well
public class Demo {
	public static void m1() {
		System.out.println("no arg method");
	}
	public static void m1(int i) {
		System.out.println("int arg method");
	}
	public static void m1(double a) {
		System.out.println("double arg method");
	}
    public static void main(String[] args) {
		m1();
		Demo.m1(20);
		Demo d1=new Demo();
		d1.m1(20.7);
	}
}
