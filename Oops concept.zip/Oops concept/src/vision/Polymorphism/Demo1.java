package vision.Polymorphism;

public class Demo1 {
  //type 2. by varying no of arguments of method
	
	public void m1() {
		System.out.println("no arg");
	}
	public void m1(int i) {
		System.out.println("1 arg");
	}
	public void m1(int i,int j) {
		System.out.println("2 arg");
	}
	public void m1(int i,int j, int k) {
		System.out.println("3 arg");
	}
	public static void main(String[] args) {
		Demo1 d1=new Demo1();
		d1.m1();
		d1.m1(10);
		d1.m1(11, 20);
		d1.m1(21,30,40);
	}
}
