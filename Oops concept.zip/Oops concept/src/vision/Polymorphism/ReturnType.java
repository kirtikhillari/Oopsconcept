package vision.Polymorphism;

public class ReturnType {
   //return type does not matter in the method overloading 
	public void m1() {
		System.out.println("void return type");
	}
	public int m1(int j) {
		System.out.println("int arg return type");
		return 0;
	}
	public static void main(String[] args) {
		ReturnType t=new ReturnType();
		t.m1();
		t.m1(20);
	}
}
