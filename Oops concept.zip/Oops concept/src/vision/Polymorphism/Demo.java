package vision.Polymorphism;

public class Demo {
  //Poly- many
  //Morphy- forms
  //one name with many forms
//person with different role-father,teacher,farmer,husband likewise
//polymorphism means same name and many forms
//if we have a method in one class with same name but different arguments is called
//method overloading.	
//if we have multiple methods in one class with same name with different argument/parameters is 
//	called method overloading.
//polymorphism types-
//1. method overloading/compile time polymorphism.
//2. method overriding/run time polymorphism
	
	//same method name but parameter data type is different.
	public void m1() {
		System.out.println("No arguments");
	}
    public void m1(int i) {
		System.out.println("int arg method");
	}
    public void m1(long l) {
	System.out.println("long arg method");
    }
    public void m1(double d1) {
	System.out.println("double arg method");
    }
    public static void main(String[] args) {
		Demo d=new Demo();
		d.m1();
		d.m1(10);
		d.m1(10l);
		d.m1(10.0);
		boolean b=true;
		int k=10;
		double d1=10.8;
		String s="XYZ";
		System.out.println(b);
		System.out.println(k);
		System.out.println(d1);
		System.out.println(s);
		
	}
}
