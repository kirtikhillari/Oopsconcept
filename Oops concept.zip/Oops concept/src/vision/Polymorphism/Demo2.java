package vision.Polymorphism;

public class Demo2 {
//type 3: by changing sequence of parameter
	public void m1(int i,double d) {
		System.out.println("method with int and double arg");
	}
	public void m1(double d,int i) {
		System.out.println("method with double and int arg");
	}
	public static void main(String[] args) {
		Demo2 d1=new Demo2();
		d1.m1(10, 12.7);
		d1.m1(289.8, 34);
	}
}
