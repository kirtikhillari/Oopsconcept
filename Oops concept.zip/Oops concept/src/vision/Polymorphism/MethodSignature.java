package vision.Polymorphism;

public class MethodSignature {
     //method signature is nothing but method name followed by method argument.
	public void m1(int a) {
		//public-access modifier
		//void-return type
		//m1()-method name
		//int a- parameter/argument of method
		//m1(int a)-method signature
	//Rules:
		//1)method signature must be different in method overloading.
	}
}
