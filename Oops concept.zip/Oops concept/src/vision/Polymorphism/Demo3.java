package vision.Polymorphism;
//in method overloading method signature must be different but method name should be same
public class Demo3 {
	public void abc(int i,double d) {
		System.out.println("int and double arg method");
	}
	public void abc(String s,float f) {
		System.out.println("String and float method arg");
	
	}
	//method abc and abcd are not overloaded method
	//because method signature is different but method name is not same.
	public void abcd(String s,float f) {
		System.out.println(s);
	}
	public void m1(short i) {
		System.out.println(i);
	}
	public static void main(String[] args) {
		Demo3 d=new Demo3();
		//explicit typecasting
		d.m1((short)10);
	}
  
}
