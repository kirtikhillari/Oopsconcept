package vision.Inheritance;

public class ParentConstructor {
  public ParentConstructor() {
	  System.out.println("Parent class constructor ");
  }
}
