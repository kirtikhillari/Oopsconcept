package vision.Inheritance;

public class Demo_this {
   public void m1() {
	   System.out.println("parent method");
   }
}
