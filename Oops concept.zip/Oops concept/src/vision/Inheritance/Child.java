package vision.Inheritance;

public class Child extends Parent {
    int i=30;
    public void m1() {
    	System.out.println("value of i : "+super.i);
    }
    public static void main(String[] args) {
		Child s=new Child();
		s.m1();
	}
}
