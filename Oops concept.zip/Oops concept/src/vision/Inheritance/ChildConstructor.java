package vision.Inheritance;

public class ChildConstructor extends ParentConstructor {
   public ChildConstructor() {
	   super();
	   //purpose of super() is to call super class constructor.
	   System.out.println("child class constructor");
	   
   }
   public static void main(String[] args) {
	   //ChildConstructor c1=new ChildConstructor();
	  // ParentConstructor p1=new ParentConstructor();
	   ParentConstructor p2=new ChildConstructor();
}
}
