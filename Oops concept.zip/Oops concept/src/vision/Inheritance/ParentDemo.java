package vision.Inheritance;

public class ParentDemo {
  public void m2() {
	  System.out.println("Parent Method Call");
  }
  public static void main(String[] args) {
	//creating parent object by using parent object.
	  ParentDemo p1=new ParentDemo();
	  p1.m2();
	  
	  //create object of child using child reference
	  
}
}
