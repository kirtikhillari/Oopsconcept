package vision.Inheritance;

public class Parent {
  int i=20;
}
