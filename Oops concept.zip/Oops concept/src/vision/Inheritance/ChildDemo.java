package vision.Inheritance;

public class ChildDemo extends ParentDemo {
  public ChildDemo() {
	  super();
	  //purpose of super() is to call super class constant
	  System.out.println("child class constructor");
  }
  public static void main(String[] args) {
	  ChildDemo c1=new ChildDemo();
	  ParentDemo p1=new ParentDemo();
	  ParentDemo p2=new ChildDemo();
}
}
