package vision.Inheritance;

public class UnicornBike {
     public void increaseSpeed() {
    	System.out.println("Speed is increased");
     }
     public void decreaseSpeed() {
    	 System.out.println("Speed is Decreased");
     }
     public static void main(String[] args) {
		UnicornBike u=new UnicornBike();
		u.decreaseSpeed();
		u.increaseSpeed();
	}
}
