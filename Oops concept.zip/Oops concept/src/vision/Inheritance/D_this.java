package vision.Inheritance;

public class D_this extends Demo_this {
 public void m1() {
	 System.out.println("child method");
 }
 public void m2() {
	 super.m1();
	 this.m1();
 }
 public static void main(String[] args) {
	D_this c1=new D_this();
	c1.m2();
	//c1.m1();
}
}
