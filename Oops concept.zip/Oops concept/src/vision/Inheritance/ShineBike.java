package vision.Inheritance;
/*
 * Inheritance is acquiring properties and behavior of one class into another class.
 * by using extends keyword we can achieve inheritance between two classes.
 * Benefits of inheritance is code re-usability.
 */
//Single Inheritance.
public class ShineBike extends UnicornBike {
    
//class mentioned to right side of extends keyword is called as superclass or parent
//class.
//class mentioned left side to extends keyword is called child class or sub class.
 public void increaseSpeed1() {
	 System.out.println("Increased speed 1");
 }
 public void decreaseSpeed1() {
	 System.out.println("Decreased speed 1");
 }
 public static void main(String[] args) {
	//child class reference and child class object(shinebike)
	 ShineBike s=new ShineBike();
	 s.increaseSpeed();
	 s.decreaseSpeed();
	 s.decreaseSpeed1();
	 s.increaseSpeed1();
	 
	 //parent reference and parent class object (unicornbike)
	 UnicornBike u=new UnicornBike();
	 u.increaseSpeed();
	 u.decreaseSpeed();
	 
	 //creating an object of child class by using parent class reference.
	 UnicornBike b1=new ShineBike();
	 b1.increaseSpeed();
	 b1.decreaseSpeed();
	 
	 //we can't create an object of parent class using child class reference.
	 //parent class=UbicornBike
	 //child class=shineBike
	 //ShineBike s1=new UnicornBike();
}
 }
