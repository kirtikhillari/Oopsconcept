package vision.Overriding;

public class C1 extends P1 {
	public String m1() {
		return "Child class method";
	}
	public Integer m2() {
		return 20;
	}

//   public Object abcd() {
//	   return "a";
//   }
//   public int abc() {
//	   return 10;
//   }
   public static void main(String[] args) {
	//we can use parent reference to hold child object 
	   P1 p1=new P1();
	   Object p2=new C1();
	   Object A1=new String();
	   //parent reference and child object.
	   P1 p3=new C1();
	   System.out.println(p3.m1());
	   System.out.println(p3.m2());
}
}
