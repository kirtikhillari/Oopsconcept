package vision.Overriding;

public class B extends A{
	public void m1() {
		System.out.println("B class Method");
	}
	public static void main(String[] args) {
		//A-parent
		//B-child
		//parent class object
		A a1 =new A(); //runtime object is of type A hence m1 method
		//parent inside class A got a chance to execute 
		a1.m1();
		//child class object
		B b1=new B();
		//runtime object is of type B  hence B class m1() method got chance to execute.
		b1.m1();
		//reference of parent and object of child 
		//we can use parent reference to hold child class object.
		A a2=new B();
		//runtime object is of type B hence B class m1() method got chance to execute.
		a2.m1();
	}

}
