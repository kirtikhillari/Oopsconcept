package vision.Overriding;
//jdk 1.5 version on words co-varient return type are allowed.
//for method overriding
//if in our parent class we have method (m1()) with return type
//as parent (object) and child class if we have same method (m1())
//with return type as child (Integer,String)then this combination.
//is said to be covarient return type.
public class P1 {
   public Object m1() {
	   return "parent class method called";
   }
   public String abcd() {
	   return "a";
	}
   public long abc() {
	   return 10;
   }
   public Object m2() {
	   return 10;
   }
   //object-> String
   //parent->child
}
