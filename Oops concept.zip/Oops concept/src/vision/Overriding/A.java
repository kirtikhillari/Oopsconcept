package vision.Overriding;

//runtime polymorphism/method overriding 
//late binding
//rules for overriding
//to achieve method overriding there
//should be inheritance relationship between two classes
//method signature must be same
//int method overriding method decision/resolution is taken care by JVM.
//based on runtime object hence method overriding is also called as runtime.

public class A {
public void m1() {
	System.out.println("A class method");
}
}
