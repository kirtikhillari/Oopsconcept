package vision.DefaultDemo;

//i can extend default class within same package.
  public class B extends A {

}
