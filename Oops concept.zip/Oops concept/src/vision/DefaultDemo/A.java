package vision.DefaultDemo;

//if we are not mentioning any access modifier it will be considered as a default 
//object creation is possible.
 class A {
	 public static void main(String[] args) {
		
	
	A a1=new A();
	 }
}
