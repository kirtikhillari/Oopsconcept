package vision.PublicAccess.Modifier;

//if access modifier for the class is public 
//can extend that class in same package also
public class B extends A{

}
