package vision.PublicAccess.Modifier;

//public access modifier.
//class-identifier which tells this is a java class.
//A-name of class
public class A {
	//accessibility of this class 
	//can we create child of this class 
	//object creation is possible or not 
	public static void main(String[] args) {
		A a1=new A();
	}
   
}
