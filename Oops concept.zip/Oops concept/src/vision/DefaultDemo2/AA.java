package vision.DefaultDemo2;

//import vision.DefaultDemo.A; 
// IF access modifier is default we can access class inside the package but not outside 
//package
//public class AA extends A {

//}
