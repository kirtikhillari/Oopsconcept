package vision.IS_A;

public class Bajaj extends Bike {
//Bike IS-A parent of Bajaj.
	
	//Object IS-A super class of all java classes.
}
