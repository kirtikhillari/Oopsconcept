package vision.IS_A;

public class Bike {
  void m1() {
	  
  }
}
