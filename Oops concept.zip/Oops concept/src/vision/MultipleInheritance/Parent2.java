package vision.MultipleInheritance;

public class Parent2 {
  public void m1() {
	  System.out.println("Parent 2 method");
  }
}
