package vision.MultipleInheritance;

public class Child extends Parent1{// extends Parent2{//we can't extends two parent classes at a time.
  public static void main(String[] args) {
	Child c1 = new Child();
	c1.m1();
	//Here which m1 method has to check by compiler is confused because m1() method present in both 
	//parent classes i.e- parent1 and parent2
	//this problem is said to be ambiguity problem or diamond problem.
}
}
