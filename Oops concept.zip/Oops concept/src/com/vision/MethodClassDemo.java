package com.vision;

public class MethodClassDemo {
	// <access modifier> <return type> < nameof method()>{}
		// we can create method inside class directly

		// code reusability

		// we can call instance method using an object
		int i;

		public void addition() {
			//public :access modifier
			//
			int a = 10;
			int b = 20;
			int sum = a + b;
			System.out.println("addition of two numbers: " + sum);
		}

		public void subtraction() {
			int a = 10;
			int b = 20;
			int subraction = a - b;
			System.out.println("subtraction of two numbers: " + subraction);
		}

		public static void main(String[] args) {
			MethodClassDemo m = new MethodClassDemo();
			System.out.println(m.i);
			m.addition();
			m.subtraction();

		}

}
