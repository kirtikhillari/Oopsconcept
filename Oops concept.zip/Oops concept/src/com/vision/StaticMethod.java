package com.vision;

public class StaticMethod {
	static int i;
	//static method is class level method
		public static void m1() {
			// public :access modifier
			// static:keyword
			// void:return type
			// m1()_; name of method
			System.out.println("hello");
		}

		public static void main(String[] args) {
			StaticMethod s=new StaticMethod();
			System.out.println(i);
			m1();
			s.m1();
			System.out.println(StaticMethod.i);
			StaticMethod.m1();
			StaticMethod s1 = new StaticMethod();
			System.out.println(s1.i);
			s1.m1();
		}

}
