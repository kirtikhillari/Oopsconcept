package com.vision;

public class InstanceMethodDemo {
	int i;

	public void m1() {
		System.out.println("method called ");
	}

	public static void main(String[] args) {
		InstanceMethodDemo d1 = new InstanceMethodDemo();
		// System.out.println(d1.i);
		d1.m1();
		InstanceMethodDemo d2 = new InstanceMethodDemo();
		// System.out.println(d2.i);
		d2.m1();
		

	}

}
