package com.vision;

//method in java is a collection/set of statement
//which perform specific task
public class MethodDemo {
	
	/*
	 * Syntax:
	 *    <access modifier><return type><method name>(parameters){
	 *    public : access mofifier
	 *    void : return type
	 *    m1() : method name
	 */
	public void m1() {
		
	}
    public static void main(String[] args) {
		for(int i=0;i<10;i++) {
			System.out.println(i);
		}
		System.out.println("Welcome to vision Edutech");
		System.out.println("abc");
	}
}
