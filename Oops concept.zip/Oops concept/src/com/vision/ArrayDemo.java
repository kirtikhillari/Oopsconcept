package com.vision;

import java.util.Arrays;

public class ArrayDemo {
   public static void main(String[] args) {
	  int []a=new int[5];
	  a[0]=1;
	  a[1]=2;
	  a[2]=3;
	  
	  System.out.println(a);
//	  for(int var :a) {
//		  System.out.println(var);
//	  }
	  
	  for(int i=0;i<a.length;i++) {
		  System.out.println(a[i]);
	  }
	  System.out.println(a.toString());
	  System.out.println(Arrays.toString(a));
}
}
