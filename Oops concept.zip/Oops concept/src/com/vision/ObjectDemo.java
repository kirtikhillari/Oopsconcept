package com.vision;
/*
 * object is an instance of class.
 * object present physically
 * object will occupy memory
 * objects are getting stores into heap memory
 * object can have state and behavior
 * with the help of new keyword we can create object;
 * object initialization is done with the help of constructor.
 */
public class ObjectDemo {
	int i;
	public static void main(String[] args) {
		 ObjectDemo a=new ObjectDemo();// way to create object
		 System.out.println(a.i);
		 //syntax: 
		 //classname reference variable=new class name();
	}

}
