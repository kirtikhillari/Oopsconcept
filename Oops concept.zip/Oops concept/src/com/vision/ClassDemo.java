package com.vision;

/*
 * class is a set of object which shares common properties and behaviors
 * class is not present physically
 * if we are creating a class it will not occupy memory
 * class is group of data members and method.
 * java class can have:
 * 1)data members
 * 2)methods
 * 3)constructor
 * 4)nested class
 * 5)interface
 */
public class ClassDemo {
	String name;
	String sirname;
	int rollno;
     public void m1() {
    	 
     }
     public void m2() {
    	 
     }
     public static void main(String[] args) {
    	 ClassDemo c1=new ClassDemo();
    	 ClassDemo c2=new ClassDemo();
    	 ClassDemo c3=new ClassDemo();
	}
}
