package com.vision;

public class Student {
 int rollNo;
 //camel casting 
 String name;
 String surName;
 
 //user define method
 public String m1() {
	 return "Student [ rollNo="+rollNo+",name="+name+",surName="+surName+" ]";
 }
//predefine method 
// toString method is predefined method present in java 
 //toString method is used to represent content present
 
 @Override
public String toString() {
	return "Student [rollNo=" + rollNo + ", name=" + name + ", surName=" + surName + "]";
}



public static void main(String[] args) {
	Student s1= new Student();
	s1.rollNo=10;
	s1.name="Neha";
	s1.surName="Patil";
	System.out.println("user created method output : "+s1.m1());
	System.out.println("jvm tostring created method output : "+s1);
	
	Student s2=new Student();
	s2.rollNo=20;
	s2.name="Sparshika";
	s2.surName="Patil";
	System.out.println("user created method output : "+s2.m1());
	System.out.println("jvm tostring created method output : "+s2);
	
}
}
