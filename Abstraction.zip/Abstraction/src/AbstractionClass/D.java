package AbstractionClass;

public abstract class D extends C {

	@Override
	void m1() {
		System.out.println("m1 method");
		
	}

	@Override
	void m2() {
		System.out.println("m2 method");
		
	}

	
  
	
}
