package AbstractionClass;

//an abstract may not have any abstract method
//but by this approach we are achieving 0% abstraction
public abstract class A {
   
	public void m1() {
		System.out.println("m1 method called");
	}
	public void m2() {
		System.out.println("m2 method called");
	}
	//static methods are allowed in abstarct class
	public static void m3() {
		System.out.println("A class static method called");
	}
	public final void m4() {
		System.out.println("m4 final method called");
	}
	public abstract void m5();
	
	//we cannot declare method into abstract class as abstract final 
	//because we cannot override final method into child class
	//abstract final void m6();
}
