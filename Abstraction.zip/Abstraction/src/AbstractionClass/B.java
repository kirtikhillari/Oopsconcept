package AbstractionClass;

public class B extends A {

	public static void main(String[] args) {
		B b1=new B();
		b1.m1();
		b1.m2();
	//abstract class object creation is not possible but 
	//we can take parent reference to hold child object.
		A a1=new B();
		a1.m1();
		//object a2=new String();
		A.m3();
		a1.m4();
		a1.m5();
	}
	@Override
	public void m5() {
		
		
	}

}
