package AbstractionClass;

abstract class C {
  static int k;
  int a;
  private int l;
  
  abstract void m1();
  
  abstract void m2();
}
