package AbstractionClass;

public class E extends D {
	@Override
	void m2() {
		System.out.println("m2 method of class E");
		
	}
    public static void main(String[] args) {
		
	}
}
