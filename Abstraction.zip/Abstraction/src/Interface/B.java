package Interface;

public class B implements A {

	@Override
	public void m1() {
		System.out.println("A interface abstract method implemented into child class B");
		
	}
	public double areaof_circle(int radius) {
		return (A.pi * radius);
	}
	public static void main(String[] args) {
		B b1=new B();
		b1.m1();
		//System.out.println(b1.m=30);
		System.out.println(b1.areaof_circle(20));
		A a1=new B();
		System.out.println(A.k);
		System.out.println(A.m);
	}

}
