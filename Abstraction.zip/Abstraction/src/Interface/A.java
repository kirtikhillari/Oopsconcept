package Interface;

//interface is defined as abstract type used specify behavior of class.
//we can achieve 100% abstraction using interfaces
//every method present inside interface is abstract method only.
//we cannot implement any method inside interface.
//interface don't have constructor.
//we cannot create object for interface
//every variable present inside interface is by default.
//"public static final"
//public : we can call it everywhere
//static: we can call variable by interface name only.
//final: once we declared value we cannot change it.
//interface can have constants and abstract method only.
public interface A {
     final int m=20;
    final int l=40;
    public static final int k=20;
    //constants
    public static final double pi=3.1414;
    
    public abstract void m1();
//    public A (){
//    super();
//}
}
