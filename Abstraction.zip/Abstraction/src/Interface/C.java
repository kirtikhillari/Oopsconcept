package Interface;

public interface C extends A{

}
