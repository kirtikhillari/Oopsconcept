package ClassProgram;

//we cannot create object for abstract class.
abstract class A {
   public static void main(String[] args) {
	 //A a1=new A();
}
}
