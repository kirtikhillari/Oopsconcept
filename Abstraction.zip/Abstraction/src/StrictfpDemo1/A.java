package StrictfpDemo1;

//fp= floating point 
//strictfp- access modifier used for floating point calculation.
//if we mentioned access modifier as a strictfp floating point calculation.
//will be done based on standard: IEEE754.
//because of that if we perform same calculation on any platform.
//it will not change.
public class A {
    public static void main(String[] args) {
		System.out.println(1222223445.23345456/2323.08976);
	}
}
