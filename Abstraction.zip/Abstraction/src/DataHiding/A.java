package DataHiding;

//data hiding-our internal data should not go outside 
//(another class)directly.
//we can achieve data hiding by making every member of a class as private. 
public class A {
	private int i;
	private void m1() {
		System.out.println("A class method");
	}

}
