package Abstraction;

//how to achieve abstraction using abstract class
//by using abstract modifier we can declare method in abstract class.
//and implementation of the method is required to give in another class.
//method which is declared inside abstract class/interface(not implemented)with access modifier
//abstract is called abstract method.
//we can implement not abstract method inside abstract class.
//if in our class anyone method is abstract compulsory we have to declare class as 
//as an abstract class
//by using abstract class we are achieving partial abstraction.
//we can create constructor in abstract class.
abstract class Demo {
	int a;
	
	//abstarct
	abstract int addition(int num1,int num2);
	//abstract int addition1(int num1,int num2);
	//abstract int addition2(int num1,int num2);
	
	//normal method/non-abstract method
	public void m1() {
		int num1=10;
		int num2=32;
		System.out.println(num1+num2);
	}
	public void m2() {
		System.out.println("hi");
	}

}
