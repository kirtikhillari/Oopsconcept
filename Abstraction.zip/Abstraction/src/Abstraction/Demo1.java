package Abstraction;

public class Demo1 extends Demo {

	@Override
	int addition(int num1, int num2) {
		System.out.println(super.a);
		return num1+num2;
	}
	public static void main(String[] args) {
		Demo1 d1=new Demo1();
		d1.addition(10, 20);
		System.out.println(d1.addition(10, 20));
	}
  
}
