package Abstraction;

// data abstraction is the property in which only essential details are shown to user.
//we can achieve abstraction in java using abstract class and interface

public class A {
  public int addition(int num1, int num2) {
	  return num1+num2;
  }
}
